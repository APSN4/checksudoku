# checksudoku
Check if any NxN Sudoku is solved correctly in Python
